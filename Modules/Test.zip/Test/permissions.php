<?php

// This file is automatically discovered by the acl:sync-permissions command.
// Define permissions for the Test module here.
//
// Example:
// return [
//     'posts.view' => [
//         'description' => 'View posts',
//         'captype' => 'read', // Optional: 'read', 'write', 'manage'
//     ],
//     'posts.create' => [
//         'description' => 'Create new posts',
//         'captype' => 'write',
//     ],
// ];

return [
    //
];