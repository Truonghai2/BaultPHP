<?php

// This file is automatically discovered by the EventServiceProvider.
// You can register event-listener mappings here for the Test module.

return [
    // \Modules\Test\Domain\Events\SomeEvent::class => [
    //     \Modules\Test\Application\Listeners\HandleSomeEvent::class,
    // ],
];